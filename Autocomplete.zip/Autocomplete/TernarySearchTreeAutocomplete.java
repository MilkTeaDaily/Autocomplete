import java.util.*;

public class TernarySearchTreeAutocomplete implements Autocomplete {
    private Node overallRoot;

    public TernarySearchTreeAutocomplete() {
        overallRoot = null;
    }
    
    // The private methods below come from TST class showed in lesson 'Search Trees -TST Implementation'
    //  They are modified to met the data type requirement and the value of the TST is not used and deleted

    // Insert the key into the tree
    private Node put(Node x, CharSequence key,int d) {
        char c = key.charAt(d);
        if (x == null) {
            x = new Node(c,false);
        }
        if      (c < x.data)               x.left  = put(x.left,  key, d);
        else if (c > x.data)               x.right = put(x.right, key, d);
        else if (d < key.length() - 1)     x.mid   = put(x.mid,   key, d + 1);
        else                               x.isTerm   = true; // reached the end of word
        return x;
    }

    // Returns subtree corresponding to given key
    private Node get(Node x, CharSequence key, int d) {
        if (x == null) return null;
        char c = key.charAt(d);
        if      (c < x.data)              return get(x.left,  key, d);
        else if (c > x.data)              return get(x.right, key, d);
        else if (d < key.length() - 1) return get(x.mid,   key, d + 1);
        else                           return x;
    }

    // Collect the keys going down the tree
    private void collect(Node x, StringBuilder prefix, List<CharSequence> list) {
        if (x == null) return;
        collect(x.left,  prefix, list);
        if (x.isTerm) list.add(prefix.toString() + x.data);
        prefix.append(x.data);
        collect(x.mid,   prefix, list);
        prefix.deleteCharAt(prefix.length() - 1);
        collect(x.right, prefix, list);
    }

    // Return the list of keys that starts with the given prefix
    private List<CharSequence> keysWithPrefix(CharSequence prefix) {
        List<CharSequence> list = new ArrayList<>();
        Node x = get(overallRoot, prefix, 0); // subtree that starts w/ prefix
        if (x == null) return list;
        if (x.isTerm) list.add(prefix); 
        collect(x.mid, new StringBuilder(prefix), list); // The collect() function modify the list
        return list;
    }

    public void addAll(Collection<? extends CharSequence> terms) {
        // TODO: Your code here
        for (CharSequence term: terms){
            overallRoot = put(overallRoot,term,0);
        }
    }

    public List<CharSequence> allMatches(CharSequence prefix) {
        List<CharSequence> result = new ArrayList<>();
        // TODO: Your code here
        result = keysWithPrefix(prefix); // The runtime is proportional to the height of the tree
        return result;
    }

    private static class Node {
        public char data;
        public boolean isTerm;
        public Node left, mid, right;

        public Node(char data, boolean isTerm) {
            this.data = data;
            this.isTerm = isTerm;
            this.left = null;
            this.mid = null;
            this.right = null;
        }
    }
}
