import java.util.*;

public class LinearSearchAutocomplete implements Autocomplete {
    private final List<CharSequence> terms;

    public LinearSearchAutocomplete() {
        this.terms = new ArrayList<>();
    }

    public void addAll(Collection<? extends CharSequence> terms) {
        // TODO: Your code here
        this.terms.addAll(terms);
    }

    public List<CharSequence> allMatches(CharSequence prefix) {
        List<CharSequence> result = new ArrayList<>();
        // TODO: Your code here
        if (prefix == null || prefix.length() == 0) {
            return result;
        }
        
        for (CharSequence term : this.terms) { // Traverse the whole dataset, N 
            if (prefix.length() <= term.length()) {
                CharSequence part = term.subSequence(0, prefix.length());
                if (CharSequence.compare(prefix, part) == 0) {
                    result.add(term);
                }
            }
        }
        return result;
    }
}
