import java.util.*;

public class BinarySearchAutocomplete implements Autocomplete {
    private final List<CharSequence> terms;

    public BinarySearchAutocomplete() {
        this.terms = new ArrayList<>();
    }

    public void addAll(Collection<? extends CharSequence> terms) {
        // TODO: Your code here
        this.terms.addAll(terms);
        this.terms.sort(CharSequence::compare);
    }

    public List<CharSequence> allMatches(CharSequence prefix) {
        List<CharSequence> result = new ArrayList<>();
        // TODO: Your code here
        if (prefix == null || prefix.length() == 0) {
            return result;
        }

        // binarySearch returns the index of the search key, if in the list; 
        // if not, returns (-(insertion point) - 1) where insertion point is the point at 
        // which the key would be inserted into the list: the index of the first element 
        // greater than the key, or list.size() if all elements in the list are less than the specified key

        // This part will solve the problem when the prefix does not exist in the dataset
        if (midPoint < 0){
            midPoint = -1 * (midPoint + 1); // Change the sign of it and still start looking at that index
        }
        
        // The runtime should be O(N/2) ? 
        for (CharSequence term: terms.subList(midPoint,this.terms.size())){ // From midpoint to end;
            if (prefix.length() <= term.length()) {
                CharSequence part = term.subSequence(0, prefix.length());
                if (CharSequence.compare(prefix, part) == 0) {
                    result.add(term);
                } else { // The end of the vicinity
                    return result;
                }
            }
        }
        return result;
    }
}
